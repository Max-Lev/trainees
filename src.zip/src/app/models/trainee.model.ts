export interface Trainee {
    id: number;
    name: string;
    subject: string;
    grade: number;
    date: string;
    email?: string;
    dateJoined?: string;
    address?: string;
    city?: string;
    country?: string;
    zip?: string;
  }
  
  export interface TraineeMonitor {
    id: number;
    name: string;
    averageGrade: number;
    passed: boolean;
  }
  
  export interface ChartData {
    id: number;
    type: string;
    title: string;
    data: any;
  }
  
  export enum ChartType {
    TRAINEE_GRADES = 'traineeGrades',
    TRAINEE_SUBJECTS = 'traineeSubjects',
    SUBJECT_AVERAGES = 'subjectAverages'
  }

  export const MOCK_DATA: Trainee[] = [
    { id: 1, name: 'John Smith', subject: 'Mathematics', grade: 85, date: '2023-01-15', email: 'john@example.com', dateJoined: '2022-09-01', address: '123 Main St', city: 'Boston', country: 'USA', zip: '02108' },
    { id: 2, name: 'Jane Doe', subject: 'Physics', grade: 72, date: '2023-01-18', email: 'jane@example.com', dateJoined: '2022-09-05', address: '456 Park Ave', city: 'New York', country: 'USA', zip: '10001' },
    { id: 1, name: 'John Smith', subject: 'Chemistry', grade: 64, date: '2023-01-22', email: 'john@example.com', dateJoined: '2022-09-01', address: '123 Main St', city: 'Boston', country: 'USA', zip: '02108' },
    { id: 3, name: 'Mike Johnson', subject: 'Mathematics', grade: 91, date: '2023-01-15', email: 'mike@example.com', dateJoined: '2022-08-15', address: '789 Elm St', city: 'Chicago', country: 'USA', zip: '60007' },
    { id: 2, name: 'Jane Doe', subject: 'Biology', grade: 58, date: '2023-01-25', email: 'jane@example.com', dateJoined: '2022-09-05', address: '456 Park Ave', city: 'New York', country: 'USA', zip: '10001' },
    { id: 4, name: 'Sara Williams', subject: 'Physics', grade: 77, date: '2023-01-20', email: 'sara@example.com', dateJoined: '2022-09-10', address: '101 Pine St', city: 'Seattle', country: 'USA', zip: '98101' },
    { id: 3, name: 'Mike Johnson', subject: 'Chemistry', grade: 83, date: '2023-01-22', email: 'mike@example.com', dateJoined: '2022-08-15', address: '789 Elm St', city: 'Chicago', country: 'USA', zip: '60007' },
    { id: 5, name: 'David Brown', subject: 'Mathematics', grade: 66, date: '2023-01-15', email: 'david@example.com', dateJoined: '2022-09-20', address: '202 Oak St', city: 'Austin', country: 'USA', zip: '78701' },
    { id: 1, name: 'John Smith', subject: 'Biology', grade: 79, date: '2023-01-25', email: 'john@example.com', dateJoined: '2022-09-01', address: '123 Main St', city: 'Boston', country: 'USA', zip: '02108' },
    { id: 4, name: 'Sara Williams', subject: 'Chemistry', grade: 82, date: '2023-01-22', email: 'sara@example.com', dateJoined: '2022-09-10', address: '101 Pine St', city: 'Seattle', country: 'USA', zip: '98101' },
    { id: 6, name: 'Emily Davis', subject: 'Mathematics', grade: 93, date: '2023-01-15', email: 'emily@example.com', dateJoined: '2022-10-01', address: '303 Maple St', city: 'Denver', country: 'USA', zip: '80202' },
    { id: 2, name: 'Jane Doe', subject: 'Mathematics', grade: 60, date: '2023-01-15', email: 'jane@example.com', dateJoined: '2022-09-05', address: '456 Park Ave', city: 'New York', country: 'USA', zip: '10001' },
    { id: 5, name: 'David Brown', subject: 'Physics', grade: 70, date: '2023-01-20', email: 'david@example.com', dateJoined: '2022-09-20', address: '202 Oak St', city: 'Austin', country: 'USA', zip: '78701' },
    { id: 3, name: 'Mike Johnson', subject: 'Biology', grade: 89, date: '2023-01-25', email: 'mike@example.com', dateJoined: '2022-08-15', address: '789 Elm St', city: 'Chicago', country: 'USA', zip: '60007' },
    { id: 7, name: 'Alex Wilson', subject: 'Chemistry', grade: 55, date: '2023-01-22', email: 'alex@example.com', dateJoined: '2022-10-05', address: '404 Cedar St', city: 'Portland', country: 'USA', zip: '97201' },
    { id: 6, name: 'Emily Davis', subject: 'Physics', grade: 88, date: '2023-01-20', email: 'emily@example.com', dateJoined: '2022-10-01', address: '303 Maple St', city: 'Denver', country: 'USA', zip: '80202' },
    { id: 4, name: 'Sara Williams', subject: 'Mathematics', grade: 75, date: '2023-01-15', email: 'sara@example.com', dateJoined: '2022-09-10', address: '101 Pine St', city: 'Seattle', country: 'USA', zip: '98101' },
    { id: 7, name: 'Alex Wilson', subject: 'Biology', grade: 62, date: '2023-01-25', email: 'alex@example.com', dateJoined: '2022-10-05', address: '404 Cedar St', city: 'Portland', country: 'USA', zip: '97201' },
    { id: 5, name: 'David Brown', subject: 'Chemistry', grade: 69, date: '2023-01-22', email: 'david@example.com', dateJoined: '2022-09-20', address: '202 Oak St', city: 'Austin', country: 'USA', zip: '78701' },
    { id: 8, name: 'Morgan Freeman', subject: 'Algebra', grade: 98, date: '2023-01-15', email: 'morgan@example.com', dateJoined: '2022-10-10', address: '505 Birch St', city: 'Miami', country: 'USA', zip: '33101' }
  ];