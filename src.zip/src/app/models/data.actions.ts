export enum SELECT_ACTIONS {
    initial = 'INITIAL',
    select_row = 'SELECT_ROW_ACTION',
    open_panel = 'OPEN_PANEL_ACTION'
  }