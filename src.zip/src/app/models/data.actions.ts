export const SELECT_ACTIONS = {
    initial:'INITAL',
    select_row:'SELECT_ROW_ACTION',
    deselect_row:'DESELECT_ROW_ACTION',
    // add_new_trainee:'ADD_NEW_TRAINEE_ACTION',
    update_existing_trainee:'UPDATE_EXISTING_TRAINEE_ACTION',
    add_trainee:'ADD_TRAINEE_ACTION',
    add_new_trainee:'ADD_NEW_TRAINEE_ACTION',
    open_panel:'OPEN_PANEL_ACTION',
    close_panel:'CLOSE_PANEL_ACTION'
}