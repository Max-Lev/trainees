import { Component, OnChanges, Input, SimpleChanges } from "@angular/core";
import { NgxChartsModule } from "@swimlane/ngx-charts";

@Component({
  selector: 'app-chart-grades-average',
  standalone: true,
  imports: [
    NgxChartsModule
  ],
  templateUrl: './chart-grades-avg-students.component.html',
  styleUrl: './chart-grades-avg-students.component.scss'
})
export class ChartGradesAverageStudetnsComponent implements OnChanges {

  // @Input() selectedTrainee: Trainee[] = [];

  // averageUtilService = inject(AverageUtilService);

  // private selectedTraineeSignal: WritableSignal<Trainee[]> = signal([]);

  @Input({ required: true }) studentsAverages: { name: string; value: number; }[] = [];
  
  @Input() xAxisLabel = '';
  @Input() yAxisLabel = '';

  // single: any[] = [];
  // multi!: any[];
  // view: [number, number] = [700, 400];
  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = true;
  showXAxisLabel = true;
  // xAxisLabel = 'Students';
  showYAxisLabel = true;
  // yAxisLabel = 'Averages';

  // colorScheme: Color = {
  //   domain: ['#5AA457', '#A10A58', '#C7B42C', '#AAAAAA'],
  //   name:'',
  //   selectable: true,
  //   group:ScaleType.Ordinal
  // };

  constructor() {
    // effect(() => {
    //   const data = this.selectedTraineeSignal().map((trainee, index) => ({
    //     name: `${trainee.name} #${trainee.id}`,
    //     value: this.averageUtilService.calculateAverage(trainee.grades!)
    //   }));
    //   this.single = data;
    // });
  }
  ngOnChanges(changes: SimpleChanges): void {
    // console.log(changes)
    // console.log(this.studentsAverages)
    // if (changes['selectedTrainee']) {
    //   // this.selectedTraineeSignal.set(this.selectedTrainee);
    // }
  }

  onSelect(event: any) {
    // console.log(event);
  }


}
