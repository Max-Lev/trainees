import { Routes } from '@angular/router';
import { AnalysisPageComponent } from './features/analysis-page/analysis-page.component';
import { DataPageComponent } from './features/data-page/data-page.component';
import { MonitorPageComponent } from './features/monitor-page/monitor-page.component';

export const routes: Routes = [
    { path: '', redirectTo: '/data', pathMatch: 'full' },
    { path: 'data', component: DataPageComponent },
    { path: 'analysis', component: AnalysisPageComponent },
    { path: 'monitor', component: MonitorPageComponent },
    { path: '**', redirectTo: '/data' }
];
