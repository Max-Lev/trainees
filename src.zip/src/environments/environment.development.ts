export const environment = {
    production: false,
    subjectsAPI: 'http://localhost:4200/assets/mock-subjects.json',
    traineesAPI: 'http://localhost:4200/assets/mock-data.json'

};
