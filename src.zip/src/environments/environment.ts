export const environment = {
    production: true,
    subjectsAPI: 'https://students-managment-b099b.web.app/assets/mock-subjects.json',
    traineesAPI: 'https://students-managment-b099b.web.app/assets/mock-data.json'
};
